define({
  "name": "广州地铁盾构施工监控信息管理系统",
  "version": "2.2.1",
  "description": "广州地铁盾构施工监控信息管理系统Historian数据对接文档.",
  "title": "地铁盾构数据对接文档",
  "url": "http://ts.gzdtjl.com:8250",
  "sampleUrl": "http://ts.gzdtjl.com:8250",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-05-10T08:40:31.486Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
