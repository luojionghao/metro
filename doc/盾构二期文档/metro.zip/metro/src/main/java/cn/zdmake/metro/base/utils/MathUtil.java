package cn.zdmake.metro.base.utils;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangcan on 2017/2/13.
 */
public class MathUtil {


    public static double getHdeviation(double x0,double y0,double x1,double y1,double x2,double y2){

        double x = (x2-x1)*(x0-x1);
        double y = ( y2-y1)*(y0-y1);
        double abs = Math.abs( x-y);
        double px = Math.pow(x2-x1,2);
        double py = Math.pow(y2-y1,2);
        double sqrt = Math.sqrt(px+py);
        return abs/sqrt;
    }

    public static double getVdeviation(double z0,double z1,double z2,double mileage0,double mileage1,double mileage2){
        double min = mileage0-mileage1;
        double max = mileage2-mileage0;
        if(min < max){
            return z0 -z1;
        }else{
            return z0 -z2;
        }
    }

    public static Boolean checkStatus(Integer category,Integer status){

        if(category == null){
            return true;
        }
        if(status>2 && status<=3){
            if(category == 2 || category==3 || category==6 || category == 7 ){
                return true;
            }
        }else if(status>3 && status<=4){
            if(category == 1 || category==3 || category==5 || category == 7 ){
                return true;
            }
        }else {
            if(category == 4 || category==5 || category==6 || category == 7 ){
                return true;
            }
        }
        return false;
    }



    public static void main(String[] args){

        String fileName = "D:\\环报表_模版1.xlsx";
        File file = new File(fileName);
        Workbook workbook = null;
        try {
            if(fileName.endsWith("xls")) {
                workbook = new HSSFWorkbook(new FileInputStream(
                        file));
            }else if(fileName.endsWith("xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(
                        file));
            }else {
                System.out.print(false);
            }
            Sheet sheet = workbook.getSheetAt(0);
            Row row = sheet.getRow(1);
            Cell cell = row.getCell((short) 16);
            cell.setCellValue(18);
            FileOutputStream out = null;
            try {
                out = new FileOutputStream(file);
                workbook.write(out);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



//       double value = getHdeviation(46338.6531,74926.2134,46338.2802,74920.1731,46337.4289,74925.0844);
//
//       System.out.print("getHdeviation"+value);
    }


}
