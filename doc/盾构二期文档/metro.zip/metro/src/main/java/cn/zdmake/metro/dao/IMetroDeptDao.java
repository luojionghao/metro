package cn.zdmake.metro.dao;

import cn.zdmake.metro.base.dao.BaseDao;
import cn.zdmake.metro.model.MetroDept;

/**
 * 部门管理数据处理接口
 * @author MAJL
 *
 */
public interface IMetroDeptDao extends BaseDao<MetroDept> {

}
